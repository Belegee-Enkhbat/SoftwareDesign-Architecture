package com.example.monolithArch;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {
    private final ImplBookService bookService;

    public HelloWorldController(ImplBookService bookService) {
        this.bookService = bookService;
    }

    @RequestMapping("/myFirstFunction2")
    public String helloWorld() {
        return "hello";
    }

    @RequestMapping("/bookExpAll")
    String listBooks(Model model) {
        model.addAttribute("Book", bookService.getAllExpensive()); // Change attribute name to "books"
        return "booksExpAll";
    }

    @RequestMapping("/bookTitle")
    String listTitles(Model model) {
        model.addAttribute("Book", bookService.getTitleBooks()); // Change attribute name to "books"
        return "bookTitle";
    }
}
