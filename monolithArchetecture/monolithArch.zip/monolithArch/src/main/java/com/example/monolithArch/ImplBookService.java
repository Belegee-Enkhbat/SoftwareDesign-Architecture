package com.example.monolithArch;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

// import com.example.monolithArch.Book;
// import com.example.monolithArch.bookRepository;
@Service
public class ImplBookService implements BookService {
    private bookRepository bookRepository;
	
    
    public ImplBookService(bookRepository bookRepository) {
		super();
		this.bookRepository = bookRepository;
	}

	@Override
	public List<Book> getAllExpensive() {
		// TODO Auto-generated method stub
		 List<Book> expensiveBooks = new ArrayList<>();
	       
		 for (Book book : bookRepository.findAll()){
	            if (book.getPrice() > 30000){
	                expensiveBooks.add(book);
	            }
	        }
	        return expensiveBooks;
	}

	@Override
	public List<String> getTitleBooks() {
		// TODO Auto-generated method stub
		 List <String> bookTitles = new ArrayList<>();
	        for(Book book : bookRepository.findAll()){
	            bookTitles.add(book.getTitle());
	        }
	        return bookTitles;
	}

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		try {
		    bookRepository.save(book);
		        }
		   catch (Exception e){
		       throw e;
		   }
	}
}